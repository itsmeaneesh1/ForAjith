package com.lti.app;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class ZsbProject1Application {

	public static void main(String[] args) {
		SpringApplication.run(ZsbProject1Application.class, args);
		System.out.println("SB Application Running..");
	}

}
