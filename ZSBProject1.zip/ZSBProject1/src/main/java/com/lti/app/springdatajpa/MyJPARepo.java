package com.lti.app.springdatajpa;

import org.springframework.data.jpa.repository.JpaRepository;

import com.lti.app.pojo.Product;

public interface MyJPARepo 	extends JpaRepository<Product, String>
{

}
