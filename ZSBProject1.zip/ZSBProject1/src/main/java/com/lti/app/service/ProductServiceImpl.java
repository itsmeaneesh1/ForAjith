package com.lti.app.service;

import java.util.ArrayList;
import java.util.List;

import javax.transaction.Transactional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.lti.app.pojo.Product;
import com.lti.app.repository.ProductRepo;
import com.lti.app.springdatajpa.MyJPARepo;

@Service
@Transactional
public class ProductServiceImpl implements ProductService
{
	//@Autowired
	//ProductRepo pRepo;
	
	@Autowired
	MyJPARepo jpaRepo;
	

	@Override
	public void addProduct(Product product) {
		//pRepo.addProduct(product);
		jpaRepo.save(product);
		
	}
	@Override
	public List<Product> getProducts() {
		//return pRepo.getProducts();
		return jpaRepo.findAll();
	}
	@Override
	public boolean updateProduct(Product product) {
		//return  pRepo.updateProduct(product);
		 jpaRepo.save(product);
		return true;
	}
	@Override
	public boolean deleteProduct(Product product) {
		jpaRepo.delete(product);
		//return pRepo.deleteProduct(product);
		return true;
	}
	@Override
	public Product searchProductById(String prodid) {
		//return pRepo.searchProductById(prodid);
		Product pp=jpaRepo.findById(prodid).get();
		return pp;
	}
	

}
